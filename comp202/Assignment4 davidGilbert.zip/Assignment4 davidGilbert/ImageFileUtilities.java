
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;

//this class contains the write and read methods

public class ImageFileUtilities {
  
  // method  writes a p3 color image file 
  public static void writePnm(Image image,String filename)throws IOException{
    BufferedWriter bw= new BufferedWriter(new FileWriter(filename));   
    
    try{
      bw.write("P3"+"\n");
      bw.write(image.getMetadata()+"\n");
      bw.write(image.getHeight()+" "+image.getWidth()+"\n");
      bw.write(image.getMaxRange()+"\n");
      for(int i=0; i<image.getHeight();i++){
        for(int j=0; j<image.getWidth();j++){
          bw.write(image.getPixel(i,j).getRed() + " ") ;
          bw.write(image.getPixel(i,j).getGreen() + " ") ;
          bw.write(image.getPixel(i,j).getBlue() + " ") ;          
        }
      }
      bw.close();
      
    }
    catch(IOException e){
      e.printStackTrace();
      System.out.print("There is a problem with the input");
    }
  }
  
   //method writes a p2 color image file 
  public static void writePgm(Image image,String filename)throws IOException{
    BufferedWriter bw= new BufferedWriter(new FileWriter(filename));   

    try{
      bw.write("P2"+"\n");
      bw.write(image.getMetadata()+"\n");
      bw.write(image.getHeight() + " " + image.getWidth() + "\n");
      bw.write(image.getMaxRange() + "\n");
      for(int i=0; i< image.getHeight();i++){
        for(int j=0; j< image.getWidth();j++){
          bw.write(image.getPixel(i,j).grey() + " ") ;
        }
      }
      bw.close();
      
    }
    catch(IOException e){
      e.printStackTrace();
      System.out.print("There is a problem with the input");
    }
  }
 
  
  //method create an image from a file (read)
  public static Image read(String filename)throws IOException{
    
   //  try{
    String metadata= "";
    int maxRange;
    File file = new File(filename);
    Scanner scan = new Scanner(file);
    
    String line1=scan.nextLine();
 //    }
 //    catch(IOException IOe){
  //     IOe.printStackTrace();
 //   System.err.print("the file could not be acces"); 

  //  }
    
    //if greyscale
    if(line1.equals("P2")){
      while(!(scan.hasNextInt())){
        
        metadata = metadata+scan.nextLine();
      }
      int a= scan.nextInt();
      int b= scan.nextInt();
      Pixel[][] pixels = new Pixel[a][b];
      
      while(scan.hasNextInt()){
        for(int i=0;i<a;i++){
          for(int j=0;j<b;j++){
            int g = scan.nextInt();
            
            Pixel dummyPixel= new Pixel(g,g,g);
            
            pixels[i][j]= dummyPixel;
          }
        }
      }
      
      maxRange = scan.nextInt();
      
      Image image = new Image(metadata,maxRange,pixels); 
       scan.close();
      return image;
    }
    // if color
    else if(line1.equals("P3")){
      while(!scan.hasNextInt()){
        
        metadata = metadata+scan.nextLine();
      }
      int a= scan.nextInt();
      int b= scan.nextInt();
      maxRange = scan.nextInt();
      Pixel[][] pixels = new Pixel[a][b];
      
      while(scan.hasNextInt()){
        for(int i=0;i<a;i++){
          for(int j=0;j<b;j++){
            int r = scan.nextInt();
            int g = scan.nextInt();
            int blue = scan.nextInt();
            Pixel dummyPixel= new Pixel(r,g,blue);
            
            pixels[i][j]= dummyPixel;
          }
        }
      }
      Image image = new Image(metadata,maxRange,pixels); 
       scan.close();
      return image ; 
         
    }
    
    try{
      throw new Exception();
    }
    catch(Exception e){
    System.err.print("Something is wrong with the first string (not p2 or p3)"); 
    }
    //this code should not be read its only there for the compiler
    Pixel dumpixel = new Pixel(0,0,0);
    Pixel[][] dummypixel = new Pixel[][]{{dumpixel}};
    Image image = new Image("",0,dummypixel);
    return image;

  }
  
  
}
