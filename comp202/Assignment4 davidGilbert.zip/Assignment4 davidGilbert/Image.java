/**
 * image class with properties metadata:string of info,maxRange: range of value for pixel,data:pixel[][] *the image
 */
public class Image {
  private String metadata;
  private int maxRange;
  private Pixel[][] data;
  
  //contructor method for image 
  public Image(String metadata,int maxRange,Pixel[][] data) { 
    try{
      if (maxRange<0){
        throw new IllegalArgumentException();
      }
    }
    catch(IllegalArgumentException e){
      System.out.print("The input value must be over 0");
    }
    this.metadata=metadata;
    this.maxRange=maxRange;
    this.data = new Pixel[data.length][data[0].length];
    for(int i=0;i<data.length;i++){
      for(int j=0;j<data[0].length;j++){
        this.data[i][j]=data[i][j];
      }
    }
  }
  

  //crops the image from a starter pixel coordinate(2 int) inclusive and an end pixel exclusive
  public void crop(int startX,int startY,int endX,int endY ){
    try{
      if(startX<0||startY<0||endX<0||endY<0||startX>data.length||startY>data[0].length||endX>data.length||endY>data[0].length){
        throw new IllegalArgumentException(); 
      }
      
      Pixel[][] data3 = new Pixel[endX-startX][endY-startY];
      for(int i=startX+1;i<=endX;i++ ){
        for(int j=startY+1;j<=endY;j++){
          data3[i-(startX+1)][j-(startY+1)]=this.data[i][j];
        }
      }
      this.data=data3;
    }
    catch(IllegalArgumentException e){
      System.out.print("The input value are not within 0 to length of the image");
    }
    
  }
  
  
  
  // this method will flip the image about the y axis if (true) and about the x axis if false
  public void flip(boolean horizontal){
    Pixel[][] data2 = new Pixel[this.getHeight()][this.getWidth()];
    if (horizontal){
      //fip y axis
      for(int i=0;i<this.getHeight() ;i++ ) {
        for(int j=0;j<this.getWidth();j++){
          data2[i][j]=this.data[i][this.getWidth()-j-1];
        }
      }
      
    }
    else{
      //flip x axis
      for(int i=0;i<this.getHeight() ;i++ ) {
        for(int j=0;j<this.getWidth();j++){
          data2[i][j]=this.data[data.length-i-1][j];
        }
      }
    }
    //overwriting data
    this.data=data2;
  }
  
  public void toGrey(){
    Pixel[][] datag = new Pixel[this.getHeight()][this.getWidth()];
    for(int i=0; i<this.getHeight();i++){
      for(int j =0;j<this.getWidth();j++){
        Pixel p = new Pixel(this.data[i][j].grey(),this.data[i][j].grey(),this.data[i][j].grey());
        datag[i][j]=p;
      }
    }
    this.data=datag;
    
  }
  
  
  // returns medata
  public String getMetadata(){
    return this.metadata ;
  }
  // returns maxRange
  public int  getMaxRange(){
    return this.maxRange;
  }
  // returns width
  public int getWidth(){
    return this.data[0].length;
  }
  // returns meheight
  public int getHeight(){
    return this.data.length; 
  }
  // returns pixel at input place
  public Pixel getPixel(int i, int j){
    return this.data[i][j]; 
  }
}