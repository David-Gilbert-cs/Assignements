/**
 * Pixel class , object with 3 int properties from 0 to 255
 */
public class Pixel {
  private int red;
  private int green;
  private int blue;
  
  // pixel constructor input for red green and blue
  public Pixel(int red,int green, int blue) throws IllegalArgumentException{ 
    try{
      if((!(-1<red) || !(red<256)||!(-1<green) || !(green<256)||!(-1<blue) || !(blue<256))){
        throw new IllegalArgumentException();
      }
      this.red=red;
      this.green=green;
      this.blue=blue;
      
      
      //  System.out.print("The input value are not within 0 to 255") ;
    }
    catch(IllegalArgumentException e){
      System.out.print("The input value are not within 0 to 255");
    }
  }
  // pixel constructor single grey input 
  public Pixel(int grey){ 
    try{  if(!(-1<grey) || !(grey<256)){
      throw new IllegalArgumentException();
    }
    
    this.red=grey;
    this.green=grey;
    this.blue=grey;
    }
    
    catch(IllegalArgumentException e){System.out.print("The input value are not within 0 to 255");
    }
  }

  
// gets the red value of pixel  
  public int getRed(){
    return this.red;
  }
// gets the green value of pixel
  public int getGreen(){
    return this.green;
  }
// gets the blue value of pixel
  public int getBlue(){
    return this.blue;
  }
// returns the grey value of pixel from the 
  public int grey(){
    return (this.getRed()+this.getGreen()+this.getBlue())/3;
  }
}
