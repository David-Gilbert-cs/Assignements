import java.io.*;

public class Comp202Photoshop {
  
  // 0= input name file, 1=output name file, 2=format of output (pgm pnm),3 = action to make
  public static void main(String[] args) throws IOException { 
    Pixel dumpixel = new Pixel(0,0,0);
    Pixel[][] dummypixel = new Pixel[][]{{dumpixel}};
    Image image= new Image("",0,dummypixel);
    if(args.length<4){
      System.out.println("please input the following :0= input name file, 1=output name file, 2=format of output (pgm pnm),3 = action to make , and 2 coordinate points if you chose to crop.");
      //create an image object *image* from the file
    }
    try{
      image= ImageFileUtilities.read(args[0]);
    }
    catch(Exception e){
      System.err.println("something went wrong while reading the file");
      return;
    }
    
    // doing the change
    //horizontal flip the image
    if(args[3].equals("-fh")){
      image.flip(true);
    }
    // vertical flip the image
    else if(args[3].equals("-fv")){
      image.flip(false);
    }
    // grey scale the image
    else if(args[3].equals("-gs")){
      image.toGrey();
    }
    //crops image the image
    else if(args[3].equals("-cr")) {
      try{
        int a = Integer.parseInt(args[4]);
        int b = Integer.parseInt(args[5]);
        int x = Integer.parseInt(args[6]);
        int y = Integer.parseInt(args[7]);
        image.crop(a,b,x,y);
      }
      catch(ArrayIndexOutOfBoundsException e){
        System.err.println("the input coordinate to crop are out of bound" );
        return;
      }
      catch(Exception e){
        System.err.println("something went wrong while trying to crop");
        return;
      }
    } else {
      System.err.println("Invalid operation.");
      return;
    }
    //creating image file
    try{
      //creating image file
      if(args[2].equals("pnm")){
        ImageFileUtilities.writePnm(image,args[1]);
      }
      else if(args[2].equals("pgm")){
        ImageFileUtilities.writePgm(image,args[1]);
      } else {
        System.err.println("Invalid file format.");
        return;
      }
      
      
    }
    catch(Exception e){
      System.out.println(e);
      System.err.println("something went wrong while trying to create a file");
      return;
    }
  }
}