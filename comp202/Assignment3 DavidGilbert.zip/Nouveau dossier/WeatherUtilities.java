/**
 * Auto Generated Java Class.
 */
import java.util.Scanner;
public class WeatherUtilities {
  
  // the main method requieres an int value corresponding to the number of days to be ceclared
  // it prints the number of good days and the min/max temperature from a scanned array of WeatherEntry
  public static void main(String[] args){
    Scanner sc = new Scanner(System.in);
   int n= Integer.parseInt(args[0]);
    WeatherEntry[] weatherEntries= new WeatherEntry[n];
    for(int i=0;i<n;i++){
     weatherEntries[i]= new WeatherEntry(sc.nextDouble(),sc.nextBoolean());
    } 
     System.out.println( "there were "+countGoodDays(weatherEntries)+"good day(s)");
    minMax(weatherEntries);
    
                          
  }
  
  //This method return the number of good days from the input double and boolean  array
public static int countGoodDays(double[] temperatureInCelsius, boolean[] isSunny){
  if(temperatureInCelsius.length!=isSunny.length){
    throw (new IllegalArgumentException());
  }
  int counter=0;
  for(int i=0;i<isSunny.length;i++){
    if(isSunny[i] &&temperatureInCelsius[i]>-30.0 ) 
      counter++;
  }
  return counter;
}

//this method count the number of good days in the input WeatherEntry array
public static int countGoodDays(WeatherEntry[] WeatherEntry){
  int counter=0;
  for(int i=0;i<WeatherEntry.length;i++){
    WeatherEntry[i].isGoodWeather();
  if(true)  {
    counter++;
    }
  }
  return counter;

}
// this method prints the min and max temperature from the input WeatherEntry array
private static void minMax(WeatherEntry[] WeatherEntry){
  double max=0;
  double min=0;
  double dummy;
  for(int i=0;i<WeatherEntry.length;i++){
    if(i==0){
  min=WeatherEntry[i].getTemperatureCelsius();
  max=min;
    }
    else{
      dummy=WeatherEntry[i].getTemperatureCelsius();
      if(dummy<min){
       min=dummy ;
      }
      if(dummy>max){
       max=dummy ;
      }
    }
  }
  System.out.println("the max temperature is "+max+" celsius and the min temperature is "+min);
}
}



