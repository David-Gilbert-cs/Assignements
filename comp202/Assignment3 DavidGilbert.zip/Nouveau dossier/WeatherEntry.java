/**
 * 
 */
public class WeatherEntry {
  
  private double temperatureInCelsius; 
  private boolean isSunny;
  
/*for testing  public static void main(String[] args){
WeatherEntry d1= new WeatherEntry(-12.0,true);
d1.display(false);
  }*/ 
  
 public WeatherEntry(double temperatureInCelsius,boolean isSunny ){
    
    this.temperatureInCelsius=temperatureInCelsius;
    this.isSunny= isSunny;
  }
  
  public double getTemperatureCelsius(){
    return this.temperatureInCelsius;
  }
  
  public boolean isGoodWeather(){
    if(getTemperatureCelsius()>(-30.0) && this.isSunny){
      return true;
    }
    else{
      return false;
    }
  }
  
  public void display(boolean isCelsius){
    if(isCelsius){
      System.out.println("It is "+getTemperatureCelsius()+" Celsius");
    }
    else{
      double far= getTemperatureCelsius()*9.0/5.0+32.0;
      System.out.print(" It is "+ far+" Farenheit" );
    }
    if(isSunny){
      System.out.print(" and is sunny");
    }
    else{
      System.out.print(" and is not sunny");
    }
    if(isGoodWeather()){
      System.out.print(" It's a good day.");
    }
    else{
      System.out.print(" It's not a good day, brace yourself.");
    }
  }
}
