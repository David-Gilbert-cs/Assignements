
public class BirthdayParadox {
  
  public static void main(String[] args){
    
    for(int i=1;i<101;i++){
      System.out.println(i+" : "+runExperiment(i));
}
// the following is for testing method :
//System.out.println(maxDay(generateAllData(10,23,365)));
    //int[] array= {1,2,3,4,5,5,6,6};
    //System.out.println(hasDuplicates(array));
    
  }
  
  // generates array of integer from 0 to range-1 included
  public static int[] generateArray(int size,int range){
    int[] randomArray= new int[size];
    for(int i=0;i<size;i++){
      randomArray[i]= (int)(Math.random()*range);
    }
    return randomArray; 
  }
  
  // generate array of array of integer from 0 to range-1
  public static int[][] generateAllData(int iterations, int size, int range){
    int[][] alldata= new int[iterations][size];
    for(int i=0;i<iterations;i++){
      alldata[i]= generateArray(size,range);      
    }
    return alldata;
  }
  
  // count the number of time an element is found within allData
  public static int countElement(int[][] allData,int element ){
    int counter = 0 ; 
    for(int i=0;i<allData.length;i++){
      for(int j=0;j<allData[i].length;j++){
        if(allData[i][j]== element){
          counter++; 
        }
      }
    }
    return counter; 
  }
  // return the day of the year which appears the most often within all data
  public static int maxDay(int[][] allData){
    int maxDay=-1; // if no days are found -1 will be returned
    int highestCount=0;
    for(int i=0; i<365; i++){
      int count=countElement(allData,i);
      if(count>highestCount){ // with this statement we get the first day which has the most count
        maxDay=i;
        highestCount=count;
      }
      
    }
    return maxDay ;  
  }
  //returns true if there are duplicates in the input array
  public static boolean hasDuplicates(int[] array){
    boolean hasDuplicates = false ;
    int[][] allData = {array}; // the data in a single array put into an array of array 
    if(2<=countElement(allData,maxDay(allData))){
      hasDuplicates= true; 
    }
    return hasDuplicates;
    
  }
  //return the proportion of array that have duplicates
  public static double runExperiment(int size){
    if (size<1){   
      throw new IllegalArgumentException(); 
    } 
    
    double trueCounter=0;   
    int[][] allData=generateAllData(200,size,365);
    for(int i=0;i<200;i++){
      if(hasDuplicates(allData[i])){
        trueCounter++;
      }
    }
    return (trueCounter/200.0) ;
  }
  
}
