#include<stdlib.h>
#include <stdio.h>


void main(){
printf("line 1 "
"line 2");


}
