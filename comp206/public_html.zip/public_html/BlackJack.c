/*
 ============================================================================
 Name        : BlackJack.c
 Author      : Bill Zhang
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Queue.h"

//Global Variable
int MAX_Num = 13;
int MAX_Suit = 4;

typedef struct Cards{
	int suit;
	int face;
}Cards;




/* using number to represent suit and face
 * int 0 - 3 represent in suit club, diamond, hearts, spades
 * int 0 - 13 represent in face ace, 1, 2, 3, 4, 5, 6, 7, 8, 9, J, Q, K
 * 15 in face represent the value of ace is 1 aka soft hand
 */

/*
 * standard blackjack rules but no min or max bet limits
 * since no extra gold is spent in the game, no surrender or double down in the game
 *
 */


void setupDeck(Cards deck[]);
void printCard(Cards a);
void swap(Cards **a, Cards **b);
void Shuffle(Cards deck[], int k);
int getValue(Cards a);
int getSum(Cards deck[], int n);
int checkAce(Cards deck[], int n);
//void gameAction(Cards deck[], Cards user[], int sumDealer);
void gamePlay(Cards deck[], int n);



int main(void) {


	printf("Content-Type:text/html\n\n");

	printf("<html>");
	printf("<head><title>BlackJackTesting</title><head>");
	printf("<body>");
	printf("<p>");
	//get 1 mana from the user upon entering the room
	printf("<input type = \"hidden\" name = \"inventory\" value=\"mana-1, gold-0\">");


	/*********************************************************/
	int k = time(NULL);
	Cards deck[52];
	setupDeck(deck);
	Shuffle(deck, k);


	/********************************************************/
	char *data = getenv("QUERY_STRING");
	int n;

	sscanf(data, "num=%d", &n);


	//printf("%d", n);

	/*****************************************************/
	if(n>0 && n<47){
		gamePlay(deck, n);
	}
	else{
		printf("%s", "Invalid Input");
	}

	/***************************************************/

	printf("</p>");
	printf("</body>");
	printf("</html>");

	/*
	gold = gold + credit;
	fp1 = fopen("text.txt", "w");
	fprintf(fp1, "%d %d %d", manna, gold, occupied);
	fclose(fp1);*/




	return 0;
}

void setupDeck(Cards deck[]){

	for(int i = 0; i < 13; i++){
		deck[i].suit = 0;
		deck[i].face = i;
	}

	for(int j = 13; j < 26; j++){
		deck[j].suit = 1;
		deck[j].face = j-13;
		}
	for(int p = 26; p < 39; p++){
		deck[p].suit = 2;
		deck[p].face = p-26;
		}
	for(int q = 39; q < 52; q++){
		deck[q].suit = 3;
		deck[q].face = q-39;
		}
}

void printCard(Cards a){
	if(a.suit == 0){
		printf("%s", "Club ");
		//printf("<body>Club </body>");

	}else if(a.suit == 1){
		printf("%s", "Diamond ");
		//printf("<body>Diamond </body>");
	}else if(a.suit == 2){
		printf("%s", "Heart ");
		//printf("<body>Heart </body>");
	}else if(a.suit == 3){
		printf("%s", "Spade ");
		//printf("<body>Spade </body>");
	}
	switch(a.face){

		case 0 :
			printf("%s", "ace ");
			//printf("<body>ace</body>");
			break;
		case 1 :
			printf("%s", "two ");
			//printf("<body>two</body>");
			break;
		case 2 :
			printf("%s", "three ");
			//printf("<body>three</body>");
			break;
		case 3 :
			printf("%s", "four ");
			//printf("<body>four</body>");
			break;
		case 4 :
			printf("%s", "five ");
			//printf("<body>five</body>");
			break;
		case 5 :
			printf("%s", "six ");
			//printf("<body>six</body>");
			break;
		case 6 :
			printf("%s", "seven ");
			//printf("<body>seven</body>");
			break;
		case 7 :
			printf("%s", "eight ");
			//printf("<body>eight</body>");
			break;
		case 8 :
			printf("%s", "nine ");
			//printf("<body>nine</body>");
			break;
		case 9 :
			printf("%s", "ten ");
			//printf("<body>ten</body>");
			break;
		case 10 :
			printf("%s", "J ");
			//printf("<body>J</body>");
			break;

		case 11 :
			printf("%s", "Q ");
			//printf("<body>Q</body>");
			break;

		case 12 :
			printf("%s", "K ");
			//printf("<body>Q</body>");

	}
}

void swap(Cards **a, Cards **b){
	Cards *temp = *a;
	*a = *b;
	*b = temp;
}

void Shuffle(Cards deck[], int k){

	for(int i = 0; i < 52; i++){


		srand(i+k);
		int j = rand() % 52;

		//printf("%d", j);
		//printf("\n");
		swap(&deck[i], &deck[j]);

	}
}

int getValue(Cards a){


	int ret = 0;
	switch(a.face){

	case 0 :
		ret = 10;
		break;
	case 1 :
		ret = 2;
		break;
	case 2 :
		ret = 3;
		break;
	case 3 :
		ret = 4;
		break;
	case 4 :
		ret = 5;
		break;
	case 5 :
		ret = 6;
		break;
	case 6 :
		ret = 7;
		break;
	case 7 :
		ret = 8;
		break;
	case 8 :
		ret = 9;
		break;
	// additional 15 to represent the soft hand (when ace is 1)
	case 15 :
		ret = 1;
		break;
	default :
		ret = 10;
		break;

	}

	return ret;
}

int getSum(Cards deck[], int n){
	int sum = 0;
	for(int i = 0; i < n; i++){

		sum = sum + getValue(deck[i]);
	}
	return sum;
}


int checkAce(Cards deck[], int n){


	int counter = 0;
	for(int i = 0; i < n; i++){
		if(deck[i].face == 0){
			counter++;
		}
	}
	return counter;
}

void gamePlay(Cards deck[], int n){
	Cards dealer[5];
	for(int i = 0; i<52; i++){
		enqueue(deck[i]);
	}
	for(int j = 0; j<5; j++){
		dealer[j] = dequeue();
	}
	int dealerNum = getSum(dealer, 5);

	Cards users[48];
	for(int a = 0; a<n; a++){
		users[a] = dequeue();
	}
	int userNum = getSum(users, n);
	if(dealerNum>userNum && dealerNum<24){
		printf("%s\n", "The House Wins!");

	} else if (dealerNum<userNum && userNum<24){
		printf("%s\n", "The User Wins!");

		//when the user wins, output a select drop box onto the browser
		printf("Content-Type:text/html\n\n");
		printf("<html>");
		printf("<body>");
		printf("<form name=rewardOption action=\"BlackJack.cgi\"  method= \"get\"> ");
		printf("<select name =\"options\">");
		printf("<option value=\"5mana\">5mana</option>");
		printf("<option value=\"4mana1gold\">4mana1gold</option>");
		printf("<option value=\"3mana2gold\">3mana2gold</option>");
		printf("<option value=\"2mana3gold\">2mana3gold</option>");
		printf("<option value=\"1mana4gold\">1mana4gold</option>");
		printf("<option value=\"fivegold\">5gold</option>");
		printf("</select");
		printf("<input type=\"submit\" value=\"enter\">");

		printf("</form>");

		char *data = getenv("QUERY_STRING");
		char input = NULL; ;
		// read a string from the environmental variable
		sscanf(data, "value=%c", input);
		// to check if the input matches certain choice, if they match, do corresponding
		//operation on the inventory
		if(input == '5'){
			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+5, gold+0\">");
		}else if(input == '4'){
			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+4, gold+1\">");
		}else if(input == '3'){

			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+3, gold+2\">");
		}else if(input == '2'){
			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+2, gold+3\">");
		}else if(input == '1'){
			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+1, gold+4\">");
		}else if(input == 'f'){
			printf("<input type=\"hidden\" name=\"inventory\" value=\"mana+0, gold+5\">");

		}
		printf("</body>");
		printf("</html>");
	}else if(dealerNum>24 && userNum<=24){
		printf("%s\n", "The Dealer Busted!");


	}else if(userNum >24 && dealerNum<=24){
		printf("%s\n", "The User Busted!");


	}else if(userNum>24 && dealerNum>24){
		printf("%s\n", "Both busted!");
	}
	else{
		printf("%s\n", "Tie!");
	}

	printf("%s\n", "Dealer's Hand: ");
	for(int c = 0; c<5; c++){
		printCard(dealer[c]);
		printf("%s", "| ");
		printf("\n");
	}
	printf("%s\n", "User's Hand: ");
	for(int d = 0; d<n; d++){
		printCard(users[d]);
		printf("%s", "| ");
		printf("\n");
	}
	return;
}





/*
void gamePlay(Cards deck[]){
	for(int i = 8; i < 52; i++){
		enqueue(deck[i]);
	}
	//four arraies to store cards
	Cards user[30];
	Cards user2[30];
	Cards dealer[30];
	Cards dealer2[30];
	//the status whether the hand is splited or not
	int split = 0;

	//deal 2 cards to the user
	user[0] = deck[0];
	user[1] = deck[1];

	//dealer gives 2 cards to himself/herself
	dealer[0] = deck[2];
	dealer[1] = deck[3];

	//display user's hand
	printf("%s\n", "Your hand: ");
	printf("<body><p>Your hand: </p></body>");
	printCard(user[0]);
	printf("%s", "| ");
	printCard(user[1]);
	printf("\n");
	//display deal's hand
	printf("\n");
	printf("%s\n", "Dealer's Hand: ");
	printCard(dealer[1]);
	printf("\n");
	printf("\n");


	//if the first two cards have the same face, the user can choose to split
	if(user[0].face == user[1].face){
		printf("%s\n", "Do you want to split? Y or N");
		char response;
		scanf("%c", &response);


		if(response == 'Y'){
			//the user splits the hand to 2 bets
			user2[0] = deck[1];
			user[1] = deck[4];
			user2[1] = deck[5];
			//the dealer splits the hand to 2 bets
			dealer2[0] = deck[3];
			dealer2[1] = deck[6];
			dealer[1] = deck[7];
			//update the split indicator
			split = 1;


		} else if (response == 'N') {
			//do nothing
		} else {
			printf("%s", "Response Invalid");
		}
	}

	//if the hand of dealer is less than 17, then the dealer has to keep drawing cards
	//until it is greater or equal to 17
	//if the dealer goes over 21 in this process, then the dealer loses.
	int n = 2;
	while(getSum(dealer, n) < 17){
		dealer[n] = dequeue();
		n++;
	}
	int sumDealer = getSum(dealer, n);
	if(sumDealer > 21){
		if(checkAce(dealer, n) > 0){
			sumDealer = sumDealer -10;
		} else {
			printCard(dealer[0]);
			printCard(dealer[2]);
			printf("%s\n", "The dealer Lost");

			//exit the game
			return;
		}
	} else {
		// if the hand is splited and the first hand is not busted,
		//do the same thing to the other hand
		if(split > 0){
				int n = 2;
				while(getSum(dealer2, n) < 17){
						dealer2[n-1] = dequeue();
						n++;
				}
				int sumDealer = getSum(dealer2, n);
				if(sumDealer > 21){
					if(checkAce(dealer2, n) > 0){
						sumDealer = sumDealer -10;
					} else {
						printf("%s", "The Dealer Lost");
						//exit the game
						return;
					}
				}
			}else {
				//do nothing
			}
	}
	**************************************************************************************
	//the setup of a hand







	if(split == 0){
		//if a hand is not splited
		gameAction(deck, user, sumDealer);
		printf("\n");
		printf("%s\n", "Dealer's Hand: ");
		for(int i = 0; i < n; i++){
			printCard(dealer[i]);
			printf("%s", "| ");
			//printf("%d", i);
		}


	} else {

		//if the hand is splited
		gameAction(deck, user, sumDealer);
		gameAction(deck, user2, sumDealer);
		printf("%s", "The Dealer's Hands: ");
		for(int i = 0; i < n; i++){
					printCard(dealer[i]);
					printf("%s", "| ");
		}
		for(int j = 0; j < n; j++){
					printCard(dealer2[j]);
					printf("%s", "| ");
				}

	}
}

void gameAction(Cards deck[], Cards user[], int sumDealer){
	for(int i = 8; i < 52; i++){
			enqueue(deck[i]);
		}
	char* hit = "hit";
	char* stand = "stand";
	//debug notice
	int length = 2;
			int i = 2;
			//starting from the third card
			while(getSum(user,length) < 21){
				//ask for user's action
				printf("%s\n", "Hit or Stand?");
				char action[10];
				scanf("%s", &action);
				//printf("%s", action);
				//if the user chooses to hit
				if(strcmp(action, hit) == 0){
					Cards temp = dequeue();
					printCard(temp);
					printf("\n");
					printf("\n");
					user[i] = temp;
					for(int j = 0; j<i; j++){
						if(checkAce(user,i)>0){
							user[j].face = 15;
						}
						else{
							//do nothing
						}
					}

					if(temp.face == 0){
						//check if the card is an ace
						if((getSum(user,length) + 10) > 21){
							//check if it is a soft hand
							temp.face = 15;
							//set the face value of the soft hand to 1
							//15 corresponding to 1 in getValue
							user[i] = temp;
						} else {
							//if not soft hand, index it to the user array
							user[i] = temp;
						}
					} else {
					user[i] = temp;
					}
					i++;
					length++;
					//deal one more card to the user
					if(getSum(user,length) > 21){
						printf("%s\n", "Busted!");
						return;
						//display "Bust" when the hand goes over 21 and exit
					} else if (getSum(user, length) == 21){
						printf("%s\n", "Black Jack!");
						return;
						//display "Black Jack"" when the hand is excatly 21 and exit
					} else {
						//do nothing and continue
					}
				} else if(strcmp(action, stand) == 0){

					int sumUser = getSum(user, length);

					//if the user chooses to stand, then calculate the value of the hand
					if(sumUser > sumDealer){
						printf("%s\n", "Winner Winner, Chicken Dinner!");
						//credit = credit - 1;
						return;
						//if the value is greater than the dealer's value, then user wins and exit
					} else if (sumUser == sumDealer) {
						//if the values are equal, the game is tied and exit
						printf("%s\n", "Tied!");
						return;


					}else {
						//otherwise the house wins and exit
						printf("%s\n", "The House Wins!");
						//credit = credit - 1;
						return;
					}

				} else {
					//if the input is neither hit nor stand, the input is invalid
					printf("%s\n", "Invalid Input!");
				}
			}
}

*/


