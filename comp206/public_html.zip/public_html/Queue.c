/*
 ============================================================================
 Name        : Queue.c
 Author      : Bill Zhang
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct Cards{
	int suit;
	int face;
}Cards;

struct Node {
	Cards data;
	struct Node* next;
};

struct Node* front = NULL;
struct Node* rear = NULL;

void enqueue(Cards x);
Cards dequeue();
int isEmpty();


void enqueue(Cards x) {
	struct Node* temp =
		(struct Node*)malloc(sizeof(struct Node));
	temp->data =x;
	temp->next = NULL;
	if(front == NULL && rear == NULL){
		front = rear = temp;
		return;
	}
	rear->next = temp;
	rear = temp;
}

Cards dequeue() {
	struct Node* temp = front;
	if(front == NULL) {
		printf("Queue is Empty\n");

	}
	if(front == rear) {
		front = rear = NULL;
	}
	else {
		front = front->next;
	}
	return temp -> data;
}

int isEmpty() {
	if(front == NULL) {
		;
		return 1;
	}else {
	return 0;
	}
}
