#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include"unencode.c"

void main(int argc, char *argv[]){

	
/*printf("Content-type: text/html\n\n");
	printf("<html><body bgcolor=\"black\" text=\"white\"><head><title> Three-eyed Raven </title></head><center><img src=\"casino.jpg\"style=\"width:1000px;height:600px;\"></center><br><center><form action=\"transporter.py \" method=\"post\" > <input type = \"hidden\" name = \"inventory\" value = \"4,3\"> <input type = \"hidden\" name = \"URL\" value = \"www.cs.mcgill.ca/~schen112/\"> <input type = \"submit\" value =\"North\"></form></center><br><form action=\"cgi-bin/room.cgi\" method=\"post\" ><input type = \"text\" name = \"command\" ><input type = \"submit\" name=\"submit\"></form></center></body></html>");*/

		







	int n = atoi(getenv("CONTENT_LENGTH"));
	char inputw[n+1]; //web input
	char inputp[n+1]; //player input
	                     

           
	char cmd[30];
	int manar, goldr, player;
	char room_resources[50];
	
	FILE *resources_read = fopen("resources.csv", "rt");  //gets the values of the room
	
	fgets(room_resources, 50, resources_read);
	sscanf(room_resources,"%d,%d,%d", &manar, &goldr, &player); //scan and format the value
	 
	fgets(inputw, n+1, stdin);
	unencode(inputw, inputw+n, inputp);
	
	sscanf(inputp, "inventory=%d,%d&command=%s", &manap, &goldp,cmd); 
	fclose(resources_read);
	if(manap == 0){
		printf("Content-type: text/html\n\n");
		printf("<html>");
		printf("<body>");
		printf("<h1>GAME OVER</h1>");
		printf("<center><img src=\"https://www.cs.mcgill.ca/~dgilbe9/images/youdied.gif\" </center>");
		printf("</body>");
		printf("</html>");
	}


	//if alive
	else{ 
		if(!strcmp( cmd , "play" )){

		// start the game   ****

		}		

		else if(strncmp(cmd, "DROP", 4) == 0){    // drop n ****

		}

		
	

		else if(!strcmp(cmd,"QUIT")){

		// stop the game   ****

		}

		else if( !strcmp( cmd , "EXIT" ) ){  //  if COMMAND is EXIT adds player things to the room
			manar = manar + manap;
			goldr = goldr + goldp;
			player = 0;  //no player in room
			manap = 0;
			goldp = 0;
			FILE *resources_update = fopen("resources.csv", "wt"); // open file with ressources separated by commas to update new value
			sprintf(room_resources, "%d,%d,%d", manar, goldr, player);
			fputs(room_resources, resources_update);
			fclose(resources_update);
			
			printf("Content-type: text/html\n\n");
			printf("<html>");
			printf("<head> sorry to see you leave <head>");
			printf("<body>");
			printf("<h1>See please don't come back we have enough money already</h1>");
			printf("<center><img src=\"https://www.cs.mcgill.ca/~dgilbe9/images/goodbye.jpg\" alt=\"Goodbye\"></center>");
			printf("</body>");
			printf("</html>");
		}


		else if(strcmp(cmd,"REFRESH")){
			printf("Content-type: text/html\n\n");
			printf("<html>");
			printf("<body>");
			printf("<h1>Print room</h1>"); // print the room

			printf("<form action=\"transporter.py\" method=\"POST\">\n"); //get fromtransporter py
   			printf("<input type=\"hidden\" name=\"currentURL\" value=\"www.cs.mcgill.ca/~dgilbe9/room.html\"/>\n");
   			printf("<input type=\"hidden\" name=\"playerInv_PY\" value=\"%d,%d\"/>\n", manap, goldp);
			printf("<button type=\"submit\" name=\"WEST\" value=\"WEST\"><i class=\"fa fa-chevron-left fa-5x\"></i></button>\n");
			printf("<button type=\"submit\" name=\"NORTH\" value=\"NORTH\"><i class=\"fa fa-chevron-up fa-5x\"></i></button>\n");
			printf("<button type=\"submit\" name=\"SOUTH\" value=\"SOUTH\"><i class=\"fa fa-chevron-down fa-5x\"></i></button>\n");
		        printf("<button type=\"submit\" name=\"EAST\" value=\"EAST\"><i class=\"fa fa-chevron-right fa-5x\"></i></button>\n</form>");	
			printf("<form action=\"a.cgi\" method=\"POST\">");
			printf("<input type=\"hidden\" name=\"playerInv_C\" value=\"%d,%d\"/>\n", manap, goldp);
    			printf("<input type=\"text\" name=\"user_command\" placeholder=\"Enter Command Here\" required/>\n");		
 			printf("<button type=\"submit\"><i class=\"fa fa-paper-plane-o fa-3x\" aria-hidden=\"true\"></i></button>\n");
    			printf("</form>");
			printf("</body>");
			printf("</html>");
		}
	}


}
