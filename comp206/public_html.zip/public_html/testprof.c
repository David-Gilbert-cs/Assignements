#include<stdio.h>
#include<stdlib.h>

int main(){
  
 printf("Content-type: text/html\n\n");

 printf("<html>\n");
   
 printf("<body>\n");

 printf("<h1> Welcome to Nightvale </h1>\n");

 printf("</body>\n");
  
 printf("</html>\n");

  
 return 0;

}

