/*
 ============================================================================
 Name        : Queue.c
 Author      : Bill Zhang
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
typedef struct Cards Cards;

void enqueue(Cards x);
Cards dequeue();
int isEmpty();

