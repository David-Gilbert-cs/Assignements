#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include <ctype.h>



void main(int argc, char *argv[]){

 // arrives as inventory=gold,mana (gold and mana are numbers)
int player = 1 ;
int room_gold=10;
int room_mana=10;
char p_gold[10];
char p_mana[10];
int player_mana,player_gold;
char room_resources[50];
char command[20];   // arrives as command=EXAMPLE ( if two word command spaces are + -> *drop n) 

int n = atoi(getenv("CONTENT_LENGTH"));
char array[n+1];
fgets(array,n+1,stdin);    // gets the content pass by submit and puts it in array
//decode
for(int k=0; k<n;k++){
	if(array[k]=='%' &&array[k+1]=='2' && array[k+2] == 'C'){
	array[k] = ',';
	int temp =k;
	k++;
	for(;k<n-2;k++){
	array[k]=array[k+2];
	} 
	k=temp;
	}

}

int i=0;
for(;i<n && !(array[i-2] == 'y' && array[i-1] =='=');i++);  // getting the gold,mana and command 
int j =0 ;
	for(;j<n && array[i] != ','; i++,j++){
	p_mana[j]=array[i];
	}

p_mana[i]= '\0';
player_mana= atoi(p_mana);
j =0 ;
i++;

	for(;j<n && array[i] != '&'; i++,j++){
	p_gold[j]=array[i];
	}
	
	
p_gold[j] = '\0';
player_gold= atoi(p_gold);
j =0 ;

for(;i<n && array[i] != '=';i++);
i++;
	for(;j<n && array[i] != '&'; i++,j++){     //should stop at the end of the submitted input from content lenght given
	if (array[i] != '+') command[j]=array[i];
		else command[j]=' ';
	}
command[j] = '\0';


if(player_mana==0){
		printf("Content-type: text/html\n\n");
		printf("<html>");
		printf("<body>");
		printf("<h1>GAME OVER</h1>");
		printf("<center><img src=\"https://www.cs.mcgill.ca/~dgilbe9/images/youdied.gif\" </center>");
		printf("</body>");
		printf("</html>");
}


FILE *resources_read = fopen("resources.csv", "r");  //gets the resources of the room
	if(resources_read==NULL){
	printf("Content-type: text/html\n\n");
	printf("<html><body> resources.csv wasnt found</body></html>");
	}
	
	int t =fscanf(resources_read,"%d,%d,%d", &room_mana, &room_gold, &player); //scan and format the value
	if(t != 3){
	printf("Content-type: text/html\n\n");
	printf("<html><body> not 3 thing scaned from resources</body></html>");
	}
	fclose(resources_read);
if(player == 0){
player=1;
FILE *resources_update = fopen("resources.csv", "w"); // set player value to 1
			fprintf(resources_update, "%d,%d,%d",room_mana, room_gold, player );

			fclose(resources_update);
}


if(strcmp(command,"PLAY") == 0){
// game program ****
}
else if(strstr(command, "DROP") != NULL){

int pay=2 ;  					// drop n only drop 2 *******
int amana = pay/2;
if(pay > player_gold){
printf("Content-type: text/html\n\n");
printf("<html><body bgcolor=\"white\" text=\"black\"><head> Three-eyed Raven MANA:%d GOLD:%d  </head><h1> you aint got that much gold pal</h1><form action=\"room.cgi\" method=\"post\" ><input type=\"hidden\" name=\"inventory\" value=\"%d,%d\"><input type = \"text\" name = \"command\" ><input type = \"submit\" name=\"submit\"></form></center></body></html>",player_mana,player_gold,player_mana,player_gold);
}
else{
player_gold -= pay;
player_mana += amana;
room_gold += pay;
FILE *resources_update = fopen("resources.csv", "w"); // open file with ressources separated by commas to update new value
			fprintf(resources_update, "%d,%d,%d",room_mana, room_gold, player );
			fclose(resources_update);
 

printf("Content-type: text/html\n\n");
printf("<html><body bgcolor=\"white\" text=\"black\"><head> Three-eyed Raven MANA:%d GOLD:%d  </head><form action=\"room.cgi\" method=\"post\" ><input type=\"hidden\" name=\"inventory\" value=\"%d,%d\"><input type = \"text\" name = \"command\" ><input type = \"submit\" name=\"submit\"></form></center></body></html>",player_mana,player_gold,player_mana,player_gold);
}
}
else if(strcmp(command,"EXIT") == 0){
 //  if COMMAND is EXIT adds player things to the room
			room_mana = room_mana + player_mana;
			room_gold = room_gold + player_gold;
			player = 0;  //no player in room
			
			FILE *resources_update = fopen("resources.csv", "w"); // open file with ressources separated by commas to update new value
			fprintf(resources_update, "%d,%d,%d",room_mana, room_gold, player );

			fclose(resources_update);
			
			printf("Content-type: text/html\n\n");
			printf("<html>");
			printf("<center>sorry to see you leave </center>");
			printf("<body>");
			printf("<center><h1>See ya please don't come back we have enough money already </h1></center>");
			printf("<center><img src=\"https://www.cs.mcgill.ca/~dgilbe9/images/goodbye.jpg\" alt=\"Goodbye\"></center>");
			printf("</body>");
			printf("</html>");
	
}
else if(strcmp(command,"REFRESH") == 0){
printf("Content-type: text/html\n\n");
printf("<html><body bgcolor=\"white\" text=\"black\"><head> Three-eyed Raven MANA:%d GOLD:%d </head><form action=\"room.cgi\" method=\"post\" ><input type=\"hidden\" name=\"inventory\" value=\"%d,%d\"><input type = \"text\" name = \"command\" ><input type = \"submit\" name=\"submit\"></form></center></body></html>",player_mana,player_gold,player_mana,player_gold);
}
else{
printf("Content-type: text/html\n\n");
printf("<html><body bgcolor=\"white\" text=\"black\"><head> Three-eyed Raven MANA:%d GOLD:%d </head><form action=\"room.cgi\" method=\"post\" ><input type=\"hidden\" name=\"inventory\" value=\"%d,%d\"><input type = \"text\" name = \"command\" ><input type = \"submit\" name=\"submit\"></form></center> enter a command ? full caps btw</body></html>",player_mana,player_gold,player_mana,player_gold);
}


}

// if needed command:%s  query :  %s   n:  %d mana:%d gold: %d 
