#include<stdio.h>

int main()
{
   printf("Content-type: text/html\n\n");

   printf("<html>");
   printf("<body>");
   printf("<center> <h1>Welcome to Nightvale</h1> </center> <img src=\"https://www.cs.mcgill.ca/~dgilbe9/images/nightvaleb.jpeg\" width=1800 height=900  >  ");
   printf("</body>");
   printf("</html>");

   return 0;
}
