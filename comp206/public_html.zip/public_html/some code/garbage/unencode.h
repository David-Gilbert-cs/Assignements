#ifndef lib_h
	#define lib_h
	void unencode(char *src, char *end, char *dest);
#endif
